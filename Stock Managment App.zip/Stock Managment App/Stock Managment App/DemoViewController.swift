//
//  DemoViewController.swift
//  Stock Managment App
//
//  Created by Apple on 09/09/20.
//  Copyright © 2020 MacFreak's  "Rt". All rights reserved.
//

import UIKit

class DemoViewController: UIViewController {

    @IBOutlet weak var txtfield: UITextField!
    @IBOutlet weak var txtfield1: UITextField!
    @IBOutlet weak var demo: UIButton!
    @IBOutlet weak var lblview: UITableView!
    @IBOutlet weak var result: UILabel!
    
    var data = ["Grocery", "Medicine", "Clothes", "Furniture","Health Product","Beauty Products" ]
    
    override func viewDidLoad() {
        super.viewDidLoad()

        lblview.isHidden = true
    }
    
    @IBAction func btn(_ sender: UIButton) {
        
//        UIView.animate(withDuration: 0.3) {
//            self.lblview.isHidden = false
//    }
        if lblview.isHidden {
            animate(toogle: true, type: demo)
        }else{
            animate(toogle: false, type: demo)
        }
                    
    }
    
    func animate(toogle: Bool, type:UIButton) {
        
        if type == demo {
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.lblview.isHidden = false
                }
        }else {
                UIView.animate(withDuration: 0.3) {
                    self.lblview.isHidden = true
                }
            }
        }else {
            if toogle {
                UIView.animate(withDuration: 0.3) {
                    self.lblview.isHidden = true
                }
        }else{
                UIView.animate(withDuration: 0.3) {
                    self.lblview.isHidden = true
                }

            }
        }
    }
    @IBAction func calculate(_ sender: UIButton) {
        

        let firstvalue = Double(txtfield.text!)
        var secondvalue = Double(txtfield1.text!)
        
        let outputvalue = Double(firstvalue! * secondvalue!)
        
        result.text = "The answer is \(outputvalue)"
    }
    
}

extension DemoViewController : UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = data[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        demo.setTitle("\(data[indexPath.row])", for: .normal)
        animate(toogle: false, type: demo)
        
    }
    
}
